#!/usr/bin/env bash

rm -rf ~/Library/Developer/CoreSimulator
