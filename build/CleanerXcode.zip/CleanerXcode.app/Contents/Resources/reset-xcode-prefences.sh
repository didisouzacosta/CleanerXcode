#!/usr/bin/env bash

defaults delete com.apple.dt.Xcode
