#!/usr/bin/env bash

xcrun simctl delete unavailable
