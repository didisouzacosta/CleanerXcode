# v0.1.0 - Build 104

• Improving clear button animations.

# v0.1.0 - Build 103

• Display free up space in toolbar menu.
• Display free up space in clear button action.
• Display free up space in each clean option inside of settings.
• Add preference to display free up space in toolbar menu.
• Move social links to main view.
• Improve button action animation.
